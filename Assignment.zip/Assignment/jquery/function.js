/*const button = document.getElementById("button");
document.addEventListener("click", function () {
    const para = document.createElement("p");
    para.textContent = "Aluthitaan Da";
    document.body.appendChild(para);
})*/

/*$(document).ready(function () {
    $("#btn").click(function () {
        $('#para').html("Aluthitaan Da!!!");
    })
})*/

/*$(document).ready(function () {
    $("#btn").click(function () {
        console.log($('input').val());
        $('#para').html("Aluthitaan Da!!!");
    })
})*/

$(document).ready(function () {
    $("#btn").click(function () {
        const data = $('input').val();
        $('p').text(data);
    })
})