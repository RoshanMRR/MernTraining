function calculate() {
    const expression = document.getElementById('expression').value;
    const result = eval(expression); 
    document.getElementById('result').textContent = result;
  }
  